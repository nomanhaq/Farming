export const sushi = '0x0e2298e3b3390e3b945a5456fbf59ecc3f55da16'
export const sushiv2 = '0xaba8cac6866b83ae4eec97dd07ed254282f6ad8a'
export const sushiAddress = '0x43a7903E3a839a67192151eE300e11198985E54b'
export const masterChefAddress = '0x245A074cA9814fB46A21562bC70fAB92F8A3F779'
