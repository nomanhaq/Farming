### YF_LP on Rinkeby & BSC
0. **Visit backend README.md 1st, then come back**
1. **Install dependencies with yarn (working with: 1.22.10, to install type: npm i -g yarn@1.22.10):**
</br>```yarn add```
2. **Run dApp:**
</br>```yarn start```
3. **If you run dApp on BSC, remember to Setup BSC in your MetaMask [HowTo](https://academy.binance.com/en/articles/connecting-metamask-to-binance-smart-chain)**